#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <time.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>

typedef struct Usuario {
char nome[100];
char email[100];
char senha[50];
int telefone[50];
char experiencia[1000];
char cidade[50];
char estado[50];
int idade[50];
char nomeart[50];
char ritmo[50];
char tipo[100];
char deletado;
} usuarios;
FILE *arq;
usuarios max[10000];

typedef struct Funcionario {
char nome[50];
int cpf[50];
char cargo[50];
char funcao[100];
char deletado;
} funcionarios;
FILE *arq;
funcionarios maximum[100];

typedef struct Relatorio {
char nome[50];
char texto[1000];
int data[15];
char deletado;
} relatorios;
FILE *arq;
relatorios maxi[1000];

typedef struct Estabelecimento {
char nome[50];
char localizacao[100];
int fone[20];
char email[50];
char cidade[50];
char estado[50];
char tipo[100];
char senha[50];
char deletado;
}estabelecimentos;
FILE *arq;
estabelecimentos maximo [1000];

void loginAdm(void);
void menuAdministrador(void);
void clientesAdministrador(void);
void estabelecimentosAdministrador(void);
void gerenciarCores(int opcao);
void montarMenuPrincipal(void);
void gerenciarMenuPrincipal(int opcao);
void sair(void);

void montarMenuCliente(void);
void gerenciarMenuCliente(int opcao);
void cadastroCliente(void);
void loginCliente(void);
void menuCliente(void);
void alterarCliente(void);
void consultarCliente(void);
void listarCliente(void);
void excluirCliente(void);

void montarMenuEstabelecimento(void);
void gerenciarMenuEstabelecimento(int opcao);
void cadastroEstabelecimento(void);
void loginEstabelecimento(void);
void menuEstabelecimento(void);
void listarEstabelecimento(void);
void alterarEstabelecimento(void);
void consultarEstabelecimento(void);
void excluirEstabelecimento(void);

void montarMenuFuncionarios(void);
void gerenciarFuncionarios(int opcao);
void cadastrarFuncionarios(void);
void alterarFuncionarios(void);
void consultarFuncionarios(void);
void excluirFuncionarios(void);

void montarMenuRelatorios(void);
void gerenciarRelatorios(int opcao);
void cadastrarRelatorios(void);
void alterarRelatorios(void);
void consultarRelatorios(void);
void excluirRelatorios(void);

void sair(void);

void retornarMensagem(const char* mensagem)
{
    printf(mensagem);
    return;
}
void sair()
{
    printf("\tObrigado por acessar nosso programa em C criado para apresenta��o do PIM!\n\n\n");
    printf("\t\t\t\t             OOOOOOOOOOO               \n");
    printf("\t\t\t\t         OOOOOOOOOOOOOOOOOOO           \n");
    printf("\t\t\t\t      OOOOOO  OOOOOOOOO  OOOOOO        \n");
    printf("\t\t\t\t    OOOOOO      OOOOO      OOOOOO      \n");
    printf("\t\t\t\t  OOOOOOOO  #   OOOOO  #   OOOOOOOO    \n");
    printf("\t\t\t\t OOOOOOOOOO    OOOOOOO    OOOOOOOOOO   \n");
    printf("\t\t\t\tOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO  \n");
    printf("\t\t\t\tOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO  \n");
    printf("\t\t\t\tOOOO  OOOOOOOOOOOOOOOOOOOOOOOOO  OOOO  \n");
    printf("\t\t\t\t OOOO  OOOOOOOOOOOOOOOOOOOOOOO  OOOO   \n");
    printf("\t\t\t\t  OOOO   OOOOOOOOOOOOOOOOOOOO  OOOO    \n");
    printf("\t\t\t\t    OOOOO   OOOOOOOOOOOOOOO   OOOO     \n");
    printf("\t\t\t\t      OOOOOO   OOOOOOOOO   OOOOOO      \n");
    printf("\t\t\t\t         OOOOOO         OOOOOO         \n");
    printf("\t\t\t\t             OOOOOOOOOOOO              \n\n");
    exit(1);
}
void configurarTela()
/////////////////////////////////////////////////////////////////////////////////////
//fun��o: Menu de op��es para escolher a cor da tela e da letra de sua prefer�ncia//
//Par�metro: N�o tem                                                             //
//output: A mudan�a de cor da tela original                                     //
/////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("A primeira cor corresponde ao fundo, e a segunda aos caracteres.\n\n");
    printf("1. Cinza/Amarelo\n");
    printf("2. Branco/Roxo\n");
    printf("3. Verde-�gua/Azul-escuro\n");
    printf("4. Preto/Branco-brilhante\n");
    printf("5. Voltar ao Menu Principal\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarCores(opcao);
}
void gerenciarCores(int opcao)
{
    switch(opcao)
    {
        case 1:
            system("color 8E");
            montarMenuPrincipal();
            break;

        case 2:
            system("color F5");
            montarMenuPrincipal();
            break;

        case 3:
            system("color B1");
            montarMenuPrincipal();
            break;

        case 4:
            system("color 0F");
            montarMenuPrincipal();
            break;
        case 5:
            montarMenuPrincipal();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            break;
    }
}
void sobre()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: tela com informa��es do projeto                                        //
//Par�metro: N�o tem                                                            //
//output: informa��es                                                          //
////////////////////////////////////////////////////////////////////////////////
{
    printf("\t\t\tPIM\n\n");
    printf("\tAn�lise e Desenvolvimento de Sistemas\n\tProjeto Integrado Multidisciplinar\n\tUNIP - Universidade Paulista\n");
    printf("\t2� Semestre - 2022\n");
    printf("\n\tUNIMUSIC - Plataforma de contrata��o de musicos.\n\n");
    printf("\tIntegrantes:\n\tRaul Sanches Pedrosa\n\tRonny Fabiano Dantas\n\tSavio Emanuel B Gon�alves\n\tVinicius Bezerra Pimentel\n\n\n");
    printf("\tNesse presente projeto tivemos a ideia de criar uma palataforma de musicos, onde no mesma existe a\n");
    printf("\tpossibilidade de cadastro de clientes e contratantes, onde os dois poder�o se consultar e conseguir informa��es \n");
    printf("\tde contato para fins trabalhistas.");
    printf("\n\n\n\tNosso muito obrigado e esperamos que goste! :D\n\n\n");
    getch();
}

void loginAdm()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Autenticar usu�rio e senha                                             //
//Par�metro: N�o tem                                                            //
//output: Autentica��o                                                         //
////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\t\t\t\t| ACESSO ADMINISTRADOR |\n\n\n");
    printf("\tDigite o login e a senha para ter acesso �s fun��es de administrador.\n\n\n");

    char login[15] = "teste";
    char login1[15];
    char senha[15] = "teste";
    char senha1[15];

    printf("Digite o Login: ");
    scanf("%s", login1);

    printf("\nDigite a Senha: ");
    scanf("%s", senha1);

    if (strcmp(login, login1) == 0 && strcmp(senha, senha1) == 0) {

        system ("cls || clear");
        printf("\n\t\t\t\tLOGADO!\n\n");
        printf("1. Entrar\n");
        printf("2. Voltar\n");
        scanf("%d", &continuar);
        system ("cls || clear");

        switch(continuar)
        {
            case 1:
                menuAdministrador();
            case 2:
                montarMenuPrincipal();
            default:
                printf("Digite uma op��o valida!\n");
                return loginAdm();
        }

                } else

                system("cls||clear");
                printf("\n\n\t\t\t\tDADOS INV�LIDOS!\n");
                printf("\nDados de administrador n�o constam.\n\n");
                printf("1. Para inserir os dados novamente.\n");
                printf("2. Para voltar  ao menu principal.\n");
                scanf("%d", &continuar);
                system("cls||clear");

                switch(continuar)
                {
                    case 1:
                        return loginAdm();
                    case 2:
                        montarMenuPrincipal();
                    default:
                        printf("Digite uma op��o v�lida!\n");
                        return loginAdm();
                }
}
void menuAdministrador()
/////////////////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ops��es para ger�nciar funcion�rios, relat�rios, clientes e estabelecimento //
//Par�metro: N�o tem                                                                         //
//output: Ops��es do menu administrador                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\tMenu de Administrador\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Gerenciar Funcion�rios\n");
    printf("2. Gerenciar Relatorios\n");
    printf("3. Gerenciar Clientes\n");
    printf("4. Gerenciar Estabelecimentos\n");
    printf("5. Voltar ao Menu Principal\n");
    printf("6. Sair do Programa\n");

    scanf("%d", &continuar);
    system("cls || clear");

    switch(continuar)
    {
        case 1:
            montarMenuFuncionarios();
            break;
        case 2:
            montarMenuRelatorios();
            break;
        case 3:
            clientesAdministrador();
            break;
        case 4:
            estabelecimentosAdministrador();
            break;
        case 5:
            montarMenuPrincipal();
            break;
        case 6:
            sair();
        default:
            printf("Digite uma op��o v�lida!\n");
            return menuAdministrador();
    }
}
void clientesAdministrador()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Mennu de ops��es de manuten��o do cliente                              //
//Par�metro: N�o tem                                                            //
//output: manuten��o do ciente                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\tMenu de Clientes\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Cadastrar Cliente\n");
    printf("2. Alterar Clientes\n");
    printf("3. Consultar Clientes\n");
    printf("4. Excluir Clientes\n");
    printf("5. Voltar ao Menu Administrador\n");

    scanf("%i", &continuar);
    system("cls || clear");

    switch(continuar)
    {
        case 1:
            cadastroCliente();
            break;
        case 2:
            alterarCliente();
            break;
        case 3:
            consultarCliente();
            break;
        case 4:
            excluirCliente();
            break;
        case 5:
            menuAdministrador();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            return clientesAdministrador();
    }
}
void estabelecimentosAdministrador()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ops��es de manuten��o do estabelecimento                       //
//Par�metro: N�o tem                                                            //
//output: Menu de estabelecimento                                              //
////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\tMenu de Estabelecimentos\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Cadastrar Estabelecimento\n");
    printf("2. Alterar Estabelecimento\n");
    printf("3. Consultar Estabelecimento\n");
    printf("4. Excluir Estabelecimento\n");
    printf("5. Voltar ao Menu Administrador\n");

    scanf("%i", &continuar);
    system("cls || clear");

    switch(continuar)
    {
        case 1:
            cadastroEstabelecimento();
            break;
        case 2:
            alterarEstabelecimento();
            break;
        case 3:
            consultarEstabelecimento();
            break;
        case 4:
            excluirEstabelecimento();
            break;
        case 5:
            menuAdministrador();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            estabelecimentosAdministrador();
    }
}
void montarMenuFuncionarios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ops��oes de manuten��es do funcion�rio                         //
//Par�metro: N�o tem                                                            //
//output: Menu do funcionario                                                  //
////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("\n\tMenu de Funcion�rios\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Cadastrar Funcion�rios\n");
    printf("2. Alterar Funcion�rios\n");
    printf("3. Consultar Funcion�rios\n");
    printf("4. Excluir Funcion�rios\n");
    printf("5. Voltar ao Menu Administrador\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarFuncionarios(opcao);
}
void gerenciarFuncionarios(int opcao)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Fun��o para ger�nciar o funcion�rio                                    //
//Par�metro: Numero intero com a ops��o                                         //
//output: Volta para a fun��o ger�nciara funcion�rio                           //
////////////////////////////////////////////////////////////////////////////////
{
    switch(opcao)
    {
        case 1:
            cadastrarFuncionarios();
            break;
        case 2:
            alterarFuncionarios();
            break;
        case 3:
            consultarFuncionarios();
            break;
        case 4:
            excluirFuncionarios();
            break;
        case 5:
            menuAdministrador();
            break;
        default:
            printf("Digite uma opc�o v�lida\n");
            return montarMenuFuncionarios();
            break;
    }
}
void cadastrarFuncionarios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de cadastro de funcion�rio                                        //
//Par�metro: N�o tem                                                            //
//output: Menu de cadrastro                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    struct Funcionario funcionarios;
    int retorno;
    arq = fopen("funcionarios.pro", "a");
    if (arq == NULL)
    {
        retornarMensagem("\nErro ao abrir arquivo");
        return;
    }
    printf("\n\t\t\t\|SISTEMA DE CADASTRO DE FUNCION�RIO|\n");
    printf("\nDigite o nome: ");
    scanf("%s", &funcionarios.nome);
    printf("\nDigite o CPF: ");
    scanf("%d", &funcionarios.cpf);
    printf("\nDigite o cargo: ");
    fflush(stdin);
    gets(funcionarios.cargo);
    printf("\nDigite a fun��o: ");
    scanf("%s", &funcionarios.funcao);
    retorno = fwrite (&funcionarios, sizeof(funcionarios), 1, arq);
    if (retorno == 1)
    {
        fclose (arq);
        retornarMensagem("\n Dados do funcion�rio inclu�dos com sucesso!");
        system("pause>nul");
        system("cls || clear");
        montarMenuFuncionarios();
    }
    else
    {
        fclose (arq);
        retornarMensagem("\n Falha ao gravar dados do funcion�rio.");
        system("pause>nul");
        system("cls || clear");
        montarMenuFuncionarios();
    }
}
void alterarFuncionarios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de altera��o de funcion�rio                                       //
//Par�metro: N�o tem                                                            //
//output: Menu de altera��o                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    arq = fopen("funcionarios.pro", "r+b");
    if (arq == NULL)
    {
        retornarMensagem("Arquivo inexistente!");
        system("pause>nul");
        system("cls || clear");
        menuAdministrador();
    }

    struct Funcionario funcionarios;
    char nome[50];
    int encontrado = 0;
    printf ("\nDigite o nome que procura: ");
    scanf ("%s", &nome);

    while (fread (&funcionarios, sizeof(funcionarios), 1, arq))
    {
        if ((funcionarios.nome[0] == nome[0]) && (funcionarios.deletado != '*'))
        {
            printf("\nNome do funcion�rio: %s\nCPF: %d\nCargo: %s\nFun��o: %s\n\n",funcionarios.nome, funcionarios.cpf, funcionarios.cargo, funcionarios.funcao);
            encontrado = 1;

            fseek(arq,sizeof(struct Funcionario)*-1, SEEK_CUR);
            printf("\nDigite o novo cargo: ");
            fflush(stdin);
            gets(funcionarios.cargo);
            printf("\nDigite a nova fun��o: ");
            scanf("%s", &funcionarios.funcao);

            fwrite(&funcionarios, sizeof(funcionarios), 1, arq);
            fseek(arq, sizeof(funcionarios)* 0, SEEK_END);

            retornarMensagem("\n Dados do funcion�rio alterados com sucesso!");
            system("pause>nul");
            system("cls || clear");
            montarMenuFuncionarios();
        }
    }
    if (!encontrado)
    {
        retornarMensagem("\Nome n�o cadastrado!\n");
        system("pause>nul");
        system("cls || clear");
        montarMenuFuncionarios();
    }
    fclose(arq);
}
void consultarFuncionarios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de consulta de funcion�rio                                        //
//Par�metro: N�o tem                                                            //
//output: Menu de consulta                                                     //
////////////////////////////////////////////////////////////////////////////////
{
    arq = fopen("funcionarios.pro", "rb");
    if (arq == NULL)
    {
        retornarMensagem("\nArquivo inexistente!");
        system("pause>nul");
        system("cls || clear");
        montarMenuFuncionarios();
    }
    struct Funcionario funcionarios;
    char nome[50];
    int encontrado = 0;
    printf ("\nDigite o nome que procura: ");
    scanf ("%s", &nome);

    while (fread (&funcionarios, sizeof(funcionarios), 1, arq))
    {
        if ((funcionarios.nome[0] == nome[0]) && (funcionarios.deletado != '*'))
        {
            printf("\nNome do funcion�rio: %s\nCPF: %d\nCargo: %s\nFun��o: %s\n",funcionarios.nome, funcionarios.cpf, funcionarios.cargo, funcionarios.funcao);
            encontrado = 1;
            system("pause>nul");
            system("cls || clear");
            menuAdministrador();
        }
    }
    if (!encontrado)
    {
        retornarMensagem("\nFuncion�rio n�o cadastrado!\n");
        system("pause>nul");
        system("cls || clear");
        montarMenuFuncionarios();
    }
    fclose(arq);
}
void excluirFuncionarios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu para excluir funcion�rio                                          //
//Par�metro: N�o tem                                                            //
//output: Menu para excluir                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    char excluir;
    printf("\t\t\t\t\t|AVISO|\n");
    printf("TODOS OS FUNCION�RIOS SER�O APAGADOS!\n");
    printf("N�O � POSS�VEL RECUPERAR!");
    printf("\n\n");
    printf("Deseja realmente apagar todos os funcion�rios? [S/N} \n");
    scanf("%s", &excluir);
    printf("\n");

    while (excluir != 's' || excluir != 'S')
    {
        if (excluir == 's' || excluir == 'S')
        {
            arq = fopen("funcionarios.pro", "w++");

            fclose(arq);
            printf("\nFuncion�rios exclu�dos como solicitado.");
            getch();
            system("clear||cls");
            montarMenuFuncionarios();

        }
        if (excluir == 'n' || excluir == 'N')
        {
            printf("\nNenhum funcion�rio foi apagado!\n\n\n\n");
            system("clear||cls");
            montarMenuFuncionarios();
        }
    }
}
void montarMenuRelatorios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de manuten��o de  relat�rio                                       //
//Par�metro: N�o tem                                                            //
//output: Menu de relat�rio                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("\n\tMenu de Relat�rios\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Cadastrar Relat�rios\n");
    printf("2. Alterar Relat�rios\n");
    printf("3. Consultar Relat�rios\n");
    printf("4. Excluir Relat�rios\n");
    printf("5. Voltar ao Menu Administrador\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarRelatorios(opcao);
}
void gerenciarRelatorios(int opcao)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ger�nciar relat�rios                                           //
//Par�metro: Numero inteiro com a ops��o                                        //
//output: ger�nciar relat�rios                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    switch(opcao)
    {
        case 1:
            cadastrarRelatorios();
            break;
        case 2:
            alterarRelatorios();
            break;
        case 3:
            consultarRelatorios();
            break;
        case 4:
            excluirRelatorios();
            break;
        case 5:
            menuAdministrador();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            break;
    }
}
void cadastrarRelatorios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de cadastro de relat�rios                                         //
//Par�metro: N�o tem                                                            //
//output: Menu de cadrastro                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    struct Relatorio relatorios;
    int retorno;
    arq = fopen("relatorios.pro", "a");
    if (arq == NULL)
    {
        retornarMensagem("Erro ao abrir arquivo");
        return;
    }
    printf("\n\t\t\t\|SISTEMA DE CADASTRO DE RELAT�RIO|\n");
    printf("\nDigite o t�tulo do rel�t�rio: ");
    scanf("%s", &relatorios.nome);
    printf("\nDigite o relat�rio: ");
    fflush(stdin);
    gets(relatorios.texto);
    printf("\nDigite a data (por extenso): ");
    scanf("%d", &relatorios.data);
    retorno = fwrite (&relatorios, sizeof(relatorios), 1, arq);
    if (retorno == 1)
    {
        fclose (arq);
        retornarMensagem("\n Relat�rio cadastrado com sucesso!");
        system("pause>nul");
        system("cls || clear");
        montarMenuRelatorios();
    }
    else
    {
        fclose (arq);
        retornarMensagem("\n Falha ao cadastrar relat�rio.");
        system("pause>nul");
        system("cls || clear");
        montarMenuRelatorios();
    }
}
void alterarRelatorios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de alternar relat�rios                                            //
//Par�metro: N�o tem                                                            //
//output: Menu de alternar                                                     //
////////////////////////////////////////////////////////////////////////////////
{
    {
        arq = fopen("relatorios.pro", "r+b");
        if (arq == NULL)
        {
            retornarMensagem("Arquivo inexistente!");
            system("pause>nul");
            system("cls || clear");
            montarMenuRelatorios();
        }

        struct Relatorio relatorios;
        char nome[50];
        int encontrado = 0;
        printf ("\nDigite o nome que procura: ");
        scanf ("%s", &nome);

        while (fread (&relatorios, sizeof(relatorios), 1, arq))
        {
            if ((relatorios.nome[0] == nome[0]) && (relatorios.deletado != '*'))
            {
                printf("\nNome do relat�rio: %s\nTexto: %s\nData:  %d\n\n",relatorios.nome, relatorios.texto, relatorios.data);
                encontrado = 1;

                fseek(arq,sizeof(struct Relatorio)*-1, SEEK_CUR);
                printf("\nDigite o novo texto: ");
                fflush(stdin);
                gets(relatorios.texto);
                printf("\nDigite a nova data: ");
                scanf("%s", &relatorios.data);

                fwrite(&relatorios, sizeof(relatorios), 1, arq);
                fseek(arq, sizeof(relatorios)* 0, SEEK_END);

                retornarMensagem("\n Dados do Relat�rio alterados com sucesso!");
                system("pause>nul");
                system("cls || clear");
                montarMenuRelatorios();
            }
        }
        if (!encontrado)
        {
            retornarMensagem("\Nome n�o cadastrado!\n");
            system("pause>nul");
            system("cls || clear");
            montarMenuRelatorios();
        }
        fclose(arq);
    }

}
void consultarRelatorios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de consulta de relat�rio                                          //
//Par�metro: N�o tem                                                            //
//output: Menu de consulta                                                     //
////////////////////////////////////////////////////////////////////////////////
{
    {
        arq = fopen("relatorios.pro", "rb");
        if (arq == NULL)
        {
            retornarMensagem("\nArquivo inexistente!");
            system("pause>nul");
            system("cls || clear");
            montarMenuRelatorios();
        }
        struct  Relatorio relatorios;
        char nome[50];
        int encontrado = 0;
        printf ("\nDigite o relat�rio que procura: ");
        scanf ("%s", &nome);

        while (fread (&relatorios, sizeof(relatorios), 1, arq))
        {
            if ((relatorios.nome[0] == nome[0]) && (relatorios.deletado != '*'))
            {
                printf("\nNome do relat�rio: %s\nTexto: %s\nData: %d\n",relatorios.nome, relatorios.texto, relatorios.data);
                encontrado = 1;
                system("pause>nul");
                system("cls || clear");
                montarMenuRelatorios();
            }
        }
        if (!encontrado)
        {
            retornarMensagem("\nRelat�rio n�o cadastrado!\n");
            system("pause>nul");
            system("cls || clear");
            montarMenuRelatorios();
        }
        fclose(arq);
    }
}
void excluirRelatorios()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de excluir relat�rio                                              //
//Par�metro: N�o tem                                                            //
//output: Menu de excluir                                                      //
////////////////////////////////////////////////////////////////////////////////
{
    char excluir;
    printf("\t\t\t\t\t|AVISO|\n");
    printf("TODOS OS RELAT�RIOS SER�O APAGADOS!\n");
    printf("N�O � POSS�VEL RECUPERAR!");
    printf("\n\n");
    printf("Deseja realmente apagar todos os relat�rios? [S/N} \n");
    scanf("%s", &excluir);
    printf("\n");

    while (excluir != 's' || excluir != 'S')
    {
        if (excluir == 's' || excluir == 'S')
        {
            arq = fopen("relatorios.pro", "w++");

            fclose(arq);
            printf("\nRelat�rios exclu�dos como solicitado.");
            getch();
            system("clear||cls");
            montarMenuRelatorios();

        }
        if (excluir == 'n' || excluir == 'N')
        {
            printf("\nNenhum relat�rio foi exclu�do!\n\n\n\n");
            system("clear||cls");
            montarMenuRelatorios();
        }
    }
}
void montarMenuCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de op��es do cliente                                              //
//Par�metro: N�o tem                                                            //
//output: Menu de cliente                                                      //
////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("\n\tMenu Cliente\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Caso j� tenha cadastro e deseja se logar.\n");
    printf("2. Caso n�o tenha cadastro e deseja criar um.\n");
    printf("3. Voltar ao menu principal.\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarMenuCliente(opcao);
}
void gerenciarMenuCliente(int opcao)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ger�nciar cliente                                              //
//Par�metro: Numero inteiro com a ops��o                                        //
//output: ger�nciar cliente                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    switch(opcao)
    {
        case 1:
            loginCliente();
            break;
        case 2:
            cadastroCliente();
            break;
        case 3:
            montarMenuPrincipal();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            montarMenuCliente();
            break;
    }
}
void cadastroCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de cadastro do cliente                                            //
//Par�metro: N�o tem                                                            //
//output: Menu de cadastro                                                     //
////////////////////////////////////////////////////////////////////////////////
{
    printf("\n\t\t\t\|SISTEMA DE CADASTRO DE CLIENTE|\n");
    arq = fopen("clientes.pro", "ab");
    struct Usuario usuarios;
    int cont, i = 0;
    int voltar;
    int adicionar;
    int opcao = 0;

    printf("\nDigite seu nome: ");
    scanf("%s", &usuarios.nome);
    printf("\nDigite seu nome art�stico: ");
    scanf("%s", &usuarios.nomeart);
    printf("\nDigite sua idade: ");
    scanf("%d", &usuarios.idade);
    printf("\nDigite o telefone: ");
    scanf("%d", &usuarios.telefone);
    printf("\nDigite seu ritmo musical: ");
    scanf("%s", &usuarios.ritmo);
    printf("\nDigite sua profiss�o: ");
    scanf("%s", &usuarios.tipo);
    printf("\nDigite sua experi�ncia profissional: ");
    scanf("%s", &usuarios.experiencia);
    printf("\nDigite sua cidade: ");
    scanf("%s", &usuarios.cidade);
    printf("\nDigite seu estado: ");
    scanf("%s", &usuarios.estado);
    printf("\nDigite o email: ");
    scanf("%s", &usuarios.email);
    printf("\nCrie uma senha: ");
    scanf("%s", &usuarios.senha);
    voltar = fwrite(&usuarios, sizeof(usuarios), 1, arq);
    fclose(arq);
    if (voltar == 1){
        printf("\nCadastro realizado com sucesso!\n");
        getch();
        system("clear || cls");
        loginCliente();
}
    else
        {
        printf("\nHouve erro ao cadastrar, favor tente novamente. \n\n");
        cadastroCliente();
    }
}
void loginCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de autentica��o do cliente                                        //
//Par�metro: N�o tem                                                            //
//output: Menu de autentica��o                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    int i = 0, valor = 1, cont = 0;
    char email[50];
    char senha[50];

    arq = fopen("clientes.pro", "rb");
    printf("\n\t\t\t\t|SISTEMA DE LOGIN DE CLIENTE|\n");
    printf("\nDigite o seu e-mail: ");
    scanf("%s", &email);
    printf("\nDigite a senha: ");
    scanf("%s", &senha);
    valor = fread(&max[i], sizeof(usuarios), 1, arq);
    printf("%d", valor);
    while (valor ==1)
    {
        if (strcmp(email, max[i].email)==0)
        {
           if (strcmp(senha, max[i].senha)==0)
            {
                fclose(arq);
                system("clear || cls");
                menuCliente();
                cont++;
            }
        }
        i++;
        valor = fread(&max[i], sizeof(usuarios), 1, arq);
    }
    if (cont ==0)
    {
        fclose(arq);
        system("cls || clear");
        printf("\nLogin ou senha incorretos! Digite novamente.\n");
        loginCliente();
    }
    getch();
    system("cls || clear");
}

void alterarCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de altera��o do cliente                                           //
//Par�metro: N�o tem                                                            //
//output: Menu de altera��o                                                    //
////////////////////////////////////////////////////////////////////////////////
{
    {
        arq = fopen("clientes.pro", "r+b");
        if (arq == NULL)
        {
            retornarMensagem("Arquivo inexistente!");
            system("pause>nul");
            system("cls || clear");
            montarMenuCliente();
        }

        struct Usuario usuarios;
        char nome[50];
        int encontrado = 0;
        printf ("\nDigite o nome que procura: ");
        scanf ("%s", &nome);

        while (fread (&usuarios, sizeof(usuarios), 1, arq))
        {
            if ((usuarios.nome[0] == nome[0]) && (usuarios.deletado != '*'))
            {
                printf("\nNome do cliente: %s", usuarios.nome);
                printf("\nNome art�stico: %s", usuarios.nomeart);
                printf("\nIdade: %d", usuarios.idade);
                printf("\nTelefone: %d", usuarios.telefone);
                printf("\nRitmo musical: %s", usuarios.ritmo);
                printf("\nProfiss�o: %s", usuarios.tipo);
                printf("\nExperi�ncia Profisional: %s", usuarios.experiencia);
                printf("\nCidade: %s", usuarios.cidade);
                printf("\nEstado: %s", usuarios.estado);
                printf("\nE-mail: %s", usuarios.email);
                encontrado = 1;

                fseek(arq,sizeof(struct Usuario)*-1, SEEK_CUR);
                printf("\n\nDigite o novo nome: ");
                fflush(stdin);
                gets(usuarios.nome);
                printf("\nDigite o novo nome art�stico: ");
                scanf("%s", &usuarios.nomeart);
                printf("\nDigite a nova idade: ");
                scanf("%d", &usuarios.idade);
                printf("\nDigite o novo telefone: ");
                scanf("%d", &usuarios.telefone);
                printf("\nDigite o novo ritmo musical: ");
                scanf("%s", &usuarios.ritmo);
                printf("\nDigite a nova profiss�o: ");
                scanf("%s", &usuarios.tipo);
                printf("\nDigite a nova experi�ncia profissional: ");
                scanf("%s", &usuarios.experiencia);
                printf("\nDigite a nova cidade: ");
                scanf("%s", &usuarios.cidade);
                printf("\nDigite o novo estado: ");
                scanf("%s", &usuarios.estado);
                printf("\nDigite a senha: ");
                scanf("%s", &usuarios.email);

                fwrite(&usuarios, sizeof(usuarios), 1, arq);
                fseek(arq, sizeof(usuarios)* 0, SEEK_END);

                retornarMensagem("\n Dados do Relat�rio alterados com sucesso!");
                system("pause>nul");
                system("cls || clear");
                montarMenuCliente();
            }
        }
        if (!encontrado)
        {
            retornarMensagem("\Nome n�o cadastrado!\n");
            system("pause>nul");
            system("cls || clear");
            montarMenuCliente();
        }
        fclose(arq);
    }

}

void consultarCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de consulta do cliente                                            //
//Par�metro: N�o tem                                                            //
//output: Menu de consulta                                                     //
////////////////////////////////////////////////////////////////////////////////
{
    {
        arq = fopen("clientes.pro", "rb");
        if (arq == NULL)
        {
            retornarMensagem("\nArquivo inexistente!");
            system("pause>nul");
            system("cls || clear");
            montarMenuCliente();
        }
        struct  Usuario usuarios;
        char nome[50];
        int encontrado = 0;
        printf ("\nDigite o cliente que procura: ");
        scanf ("%s", &nome);

        while (fread (&usuarios, sizeof(usuarios), 1, arq))
        {
            if ((usuarios.nome[0] == nome[0]) && (usuarios.deletado != '*'))
            {
                printf("\nNome do cliente: %s", usuarios.nome);
                printf("\nNome art�stico: %s", usuarios.nomeart);
                printf("\nIdade: %d", usuarios.idade);
                printf("\nTelefone: %d", usuarios.telefone);
                printf("\nRitmo musical: %s", usuarios.ritmo);
                printf("\nProfiss�o: %s", usuarios.tipo);
                printf("\nExperi�ncia Profisional: %s", usuarios.experiencia);
                printf("\nCidade: %s", usuarios.cidade);
                printf("\nEstado: %s", usuarios.estado);
                printf("\nE-mail: %s", usuarios.email);
                encontrado = 1;
                system("pause>nul");
                system("cls || clear");
                montarMenuCliente();
            }
        }
        if (!encontrado)
        {
            retornarMensagem("\nRelat�rio n�o cadastrado!\n");
            system("pause>nul");
            system("cls || clear");
            montarMenuCliente();
        }
        fclose(arq);
    }
}

void excluirCliente(void)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu para excluir o cliente                                            //
//Par�metro: N�o tem                                                            //
//output: Menu de excluir                                                      //
////////////////////////////////////////////////////////////////////////////////
{
    char excluir;
    printf("\t\t\t\t\tAVISO\n");
    printf("TODOS OS CLIENTES SER�O APAGADOS!\n");
    printf("N�O � POSS�VEL RECUPERAR!");
    printf("\n\n");
    printf("Deseja realmente apagar todos os clientes? [S/N} \n");
    scanf("%s", &excluir);
    printf("\n");

    while (excluir != 's' || excluir != 'S')
    {
        if (excluir == 's' || excluir == 'S')
        {
            arq = fopen("clientes.pro", "w++");

            fclose(arq);
            printf("Clientes exclu�dos como solicitado.");
            getch();
            system("clear||cls");
            montarMenuPrincipal();

        }
        if (excluir == 'n' || excluir == 'N')
        {
            printf("Nenhum cliente foi apagado!\n\n\n\n");
            system("clear||cls");
            menuCliente();
        }
    }
}
void listarCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu para listar o cliente                                             //
//Par�metro: N�o tem                                                            //
//output: Menu de lista                                                        //
////////////////////////////////////////////////////////////////////////////////
{
    int i = 0, retorno;

    arq = fopen("clientes.pro", "a+b");
    if (arq == NULL){
       printf ("\nErro!\nO arquivo da lista n�o pode ser aberto!\n");
       getch();
       exit(1);
    }
    retorno = fread(&max[i], sizeof(usuarios), 1, arq);
    while (retorno == 1){
      printf("\n Nome: %s",max[i].nome);
      printf("\n Nome art�stico: %s",max[i].nomeart);
      printf("\n Idade: %d",max[i].idade);
      printf("\n Telefone: %d",max[i].telefone);
      printf("\n Ritmo musical: %s",max[i].ritmo);
      printf("\n Profiss�o: %s",max[i].tipo);
      printf("\n Experi�ncia Profissional: %s",max[i].experiencia);
      printf("\n Cidade: %s",max[i].cidade);
      printf("\n Estado: %s",max[i].estado);
      printf("\n E-mail: %s\n",max[i].email);
      i++;
      retorno = fread(&max[i], sizeof(usuarios), 1, arq);
    }
    printf(" \n\n %d Contatos salvos!\n ", i);
    getch();
    fclose(arq);
    system("cls || clear");
    menuEstabelecimento();
}
void menuCliente()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de op��es do cliente                                              //
//Par�metro: N�o tem                                                            //
//output: Menu cliente                                                         //
////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\tMenu do Cliente\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Alterar Cadastro\n");
    printf("2. Excluir Cadastro\n");
    printf("3. Listar Estabelecimentos\n");
    printf("4. Voltar ao Menu Principal\n");
    printf("5. Sair do Programa\n");

    scanf("%i", &continuar);
    system("cls || clear");

    switch(continuar)
    {
        case 1:
            alterarCliente();
            break;
        case 2:
            excluirCliente();
            break;
        case 3:
            listarEstabelecimento();
            break;
        case 4:
            montarMenuPrincipal();
        case 5:
            sair();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            return menuCliente();
    }
}
void montarMenuEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de op��es do estabelecimento                                      //
//Par�metro: N�o tem                                                            //
//output: Menu de estabelecimento                                              //
////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("\n\tMenu de Estabelecimento\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Caso j� tenha cadastro e deseja se logar.\n");
    printf("2. Caso n�o tenha cadastro e deseja criar um.\n");
    printf("3. Voltar ao menu principal.\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarMenuEstabelecimento(opcao);
}
void gerenciarMenuEstabelecimento(int opcao)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ger�nciar o estabelecimento                                    //
//Par�metro: Numero inteiro com a ops��o                                        //
//output: ger�nciar estabelecimento                                            //
////////////////////////////////////////////////////////////////////////////////
{
    switch(opcao)
    {
        case 1:
            loginEstabelecimento();
            break;
        case 2:
            cadastroEstabelecimento();
            break;
        case 3:
            montarMenuPrincipal();
        default:
            printf("Digite uma op��o v�lida!\n");
            montarMenuEstabelecimento();
            break;
    }
}
void menuEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de op��es do estabelecimento                                      //
//Par�metro: N�o tem                                                            //
//output: Menu estabelecimento                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    int continuar = 0;

    printf("\n\tMenu do Estabelecimento\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Alterar Cadastro\n");
    printf("2. Excluir Cadastro\n");
    printf("3. Listar Clientes\n");
    printf("4. Voltar ao Menu Principal\n");
    printf("5. Sair do Programa\n");

    scanf("%i", &continuar);
    system("cls || clear");

    switch(continuar)
    {
        case 1:
            alterarEstabelecimento();
            break;
        case 2:
            excluirEstabelecimento();
            break;
        case 3:
            listarCliente();
            break;
        case 4:
            montarMenuPrincipal();
        case 5:
            sair();
            break;
        default:
            printf("Digite uma op��o v�lida!\n");
            return menuEstabelecimento();
    }
}
void cadastroEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de cadastro do estabelecimento                                    //
//Par�metro: N�o tem                                                            //
//output: Menu estabeleciemnto                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    printf("\n\t\t\t|SISTEMA DE CADASTRO DE ESTABELECIMENTO|\n");
    arq = fopen("estabelecimento.pro", "ab");
    struct Estabelecimento estabelecimentos;
    int cont, i = 0;
    int voltar;
    int adicionar;
    int opcao = 0;

    printf("\nQual o nome do estabelecimento:");
    scanf("%s", &estabelecimentos.nome);
    printf("\nTelefone do estabelecimento: ");
    scanf("%d", &estabelecimentos.fone);
    printf("\nQual o estado: ");
    scanf("%s", &estabelecimentos.estado);
    printf("\nQual a cidade: ");
    scanf("%s", &estabelecimentos.cidade);
    printf("\nEndere�o do estabelecimento: ");
    scanf("%s", &estabelecimentos.localizacao);
    printf("\nQual o tipo do estabelecimento (ex:casa de show, bar, produtora, empres�rio): ");
    scanf("%s", &estabelecimentos.tipo);
    printf("\nQual o e-mail do estabelecimento: ");
    scanf("%s", &estabelecimentos.email);
    printf("\nCrie uma senha: ");
    scanf("%s", &estabelecimentos.senha);

    voltar = fwrite(&estabelecimentos, sizeof(estabelecimentos), 1, arq);
    fclose(arq);
    if (voltar == 1){
        printf("\nParab�ns voc� esta cadastrado na nossa plataforma!\n");
        getch();
        system("clear || cls");
        loginEstabelecimento();
}
    else
        {
        printf("\nHouve erro ao cadastrar, favor tente novamente.\n");
        cadastroEstabelecimento();
    }
}
void loginEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de autentica��o do estabelecimento                                //
//Par�metro: N�o tem                                                            //
//output: Menu de autentica��o                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    int i = 0, valor = 1, cont = 0;
    char email[50];
    char senha[50];

    arq = fopen("estabelecimento.pro", "rb");
    printf("\n\t\t\t\t|SISTEMA DE LOGIN DE ESTABELECIMENTO|\n");
    printf("\nDigite o seu e-mail: ");
    scanf("%s", &email);
    printf("\nDigite a senha: ");
    scanf("%s", &senha);
    valor = fread(&maximo[i], sizeof(estabelecimentos), 1, arq);
    printf("%d", valor);
    while (valor ==1)
    {
        if (strcmp(email, maximo[i].email)==0)
        {
           if (strcmp(senha, maximo[i].senha)==0)
            {
                fclose(arq);
                system("clear || cls");
                menuEstabelecimento();
                cont++;
            }
        }
        i++;
        valor = fread(&maximo[i], sizeof(estabelecimentos), 1, arq);
    }
    if (cont ==0)
    {
        fclose(arq);
        system("cls || clear");
        printf("\nLogin ou senha incorreto! Digite novamente.\n");
        loginEstabelecimento();
    }
    getch();
    system("cls || clear");
}

void alterarEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de alterar o estabelecimento                                     //
//Par�metro: N�o tem                                                            //
//output: Menu estabeleciemnto                                                 //
////////////////////////////////////////////////////////////////////////////////
{
arq = fopen("estabelecimento.pro", "r+b");

    if (arq == NULL)

    {
        retornarMensagem("Arquivo inexistente!");
        system("pause>nul");
        system("cls || clear");
        menuEstabelecimento();
    }

    struct Estabelecimento estabelecimentos;
    char nome[50];
    int encontrado = 0;
    int valor;
    printf ("\nDigite o nome que procura: ");
    scanf ("%s", &nome);
    while (fread (&estabelecimentos, sizeof(estabelecimentos), 1, arq))
    {
        if ((estabelecimentos.nome[0] == nome[0]) && (estabelecimentos.deletado != '*'))
        {
            printf("\nNome do estabelecimento: %s\n",estabelecimentos.nome);
            printf("\nTelefone do estabelecimento: %d\n",estabelecimentos.fone);
            printf("\nEstado: %s\n",estabelecimentos.estado);
            printf("\nCidade:  %s\n",estabelecimentos.cidade);
            printf("\nEndere�o do estabelecimento:  %s\n",estabelecimentos.localizacao);
            printf("\nTipo do estabelecimento: %s\n",estabelecimentos.tipo);
            printf("\nE-mail do estabelecimento:  %s\n",estabelecimentos.email);

            encontrado = 1;

            fseek(arq,sizeof(struct Estabelecimento)*-1, SEEK_CUR);

            printf("\nDigite novo nome: ");
            fflush(stdin);
            gets(estabelecimentos.nome);
            printf("\nDigite novo telefone: ");
            scanf(" %s", &estabelecimentos.fone);
            printf("\nDigite novo estado: ");
            scanf(" %s", &estabelecimentos.estado);
            printf("\nDigite nova cidade: ");
            scanf(" %s", &estabelecimentos.cidade);
            printf("\nDigite seu novo endere�o: ");
            scanf(" %s", &estabelecimentos.localizacao);
            printf("\nDigite sua nova senha: ");
            scanf(" %s", &estabelecimentos.senha);


            fwrite(&estabelecimentos, sizeof(estabelecimentos), 1, arq);
            fseek(arq, sizeof(estabelecimentos)* 0, SEEK_END);

            retornarMensagem("\n Dados do funcion�rio alterados com sucesso!");
            system("pause>nul");
            system("cls || clear");
            menuEstabelecimento();
        }
    }
    if (!encontrado)
    {
        retornarMensagem("\Nome n�o cadastrado!\n");
        system("pause>nul");
        system("cls || clear");
        menuEstabelecimento();
    }
    fclose(arq);
}

void consultarEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de consulta do estabelecimento                                    //
//Par�metro: N�o tem                                                            //
//output: Menu estabeleciemnto                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    {
        arq = fopen("estabelecimento.pro", "rb");
        if (arq == NULL)
        {
            retornarMensagem("\nArquivo inexistente!");
            system("pause>nul");
            system("cls || clear");
            montarMenuEstabelecimento();
        }
        struct  Estabelecimento estabelecimentos;
        char nome[50];
        int encontrado = 0;
        printf ("\nDigite o estabelecimento que procura: ");
        scanf ("%s", &nome);

        while (fread (&estabelecimentos, sizeof(estabelecimentos), 1, arq))
        {
            if ((estabelecimentos.nome[0] == nome[0]) && (estabelecimentos.deletado != '*'))
            {
                printf("\nNome do estabelecimento: %s\n",estabelecimentos.nome);
                printf("\nTelefone do estabelecimento: %d\n",estabelecimentos.fone);
                printf("\nEstado: %s\n",estabelecimentos.estado);
                printf("\nCidade:  %s\n",estabelecimentos.cidade);
                printf("\nEndere�o do estabelecimento:  %s\n",estabelecimentos.localizacao);
                printf("\nTipo do estabelecimento: %s\n",estabelecimentos.tipo);
                printf("\nE-mail do estabelecimento:  %s\n",estabelecimentos.email);
                encontrado = 1;
                system("pause>nul");
                system("cls || clear");
                montarMenuEstabelecimento();
            }
        }
        if (!encontrado)
        {
            retornarMensagem("\Estabelecimento n�o cadastrado!\n");
            system("pause>nul");
            system("cls || clear");
            montarMenuEstabelecimento();
        }
        fclose(arq);
    }
}

void excluirEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de excluir o estabelecimento                                      //
//Par�metro: N�o tem                                                            //
//output: Menu estabeleciemnto                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    char excluir;
    printf("\t\t\t\t\t|AVISO|\n");
    printf("TODOS OS ESTABELECIMENTOS SER�O APAGADOS!\n");
    printf("N�O � POSS�VEL RECUPERAR!");
    printf("\n\n");
    printf("Deseja realmente apagar todos os estabelecimentos? [S/N} \n");
    scanf("%s", &excluir);
    printf("\n");

    while (excluir != 's' || excluir != 'S')
    {
        if (excluir == 's' || excluir == 'S')
        {
            arq = fopen("estabelecimento.pro", "w++");
            fclose(arq);
            printf("Todos os estabelecimentos foram exclu�dos com sucesso.");
            getch();
            system("clear||cls");
            montarMenuPrincipal();

        }
        if (excluir == 'n' || excluir == 'N')
        {
            printf("Nenhum estabelecimento foi exclu�do!\n\n\n\n");
            system("clear||cls");
            menuEstabelecimento();
        }
    }
}

void listarEstabelecimento()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de listar o estabelecimento                                       //
//Par�metro: N�o tem                                                            //
//output: Menu estabeleciemnto                                                 //
////////////////////////////////////////////////////////////////////////////////
{
    int i = 0, retorno;

    arq = fopen("estabelecimento.pro", "r");
    if (arq == NULL){
       printf ("\nErro!\nO arquivo da lista n�o pode ser aberto!\n");
       getch();
       exit(1);
    }
    retorno = fread(&maximo[i], sizeof(estabelecimentos), 1, arq);
    while (retorno == 1){
      printf("\n Nome: %s",maximo[i].nome);
      printf("\n Endere�o: %s",maximo[i].localizacao);
      printf("\n Estado: %s",maximo[i].estado);
      printf("\n Cidade: %s",maximo[i].cidade);
      printf("\n Telefone: %d",maximo[i].fone);
      printf("\n Tipo Estabelecimento: %s",maximo[i].tipo);
      printf("\n E-mail: %s\n",maximo[i].email);
      i++;
      retorno = fread(&maximo[i], sizeof(estabelecimentos), 1, arq);
    }
    printf(" \n\n %d Contatos salvos!\n ", i);
    getch();
    fclose(arq);
    system("cls || clear");
    menuCliente();
}

void montarMenuPrincipal()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de op��es do menu principal                                       //
//Par�metro: N�o tem                                                            //
//output: Menu principal                                                       //
////////////////////////////////////////////////////////////////////////////////
{
    int opcao = 0;
    printf("\n\tMenu Principal\n\n");
    printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
    printf("1. Menu Administrador\n");
    printf("2. Menu Cliente\n");
    printf("3. Menu Estabelecimento\n");
    printf("4. Configurar Cores\n");
    printf("5. Sobre\n");
    printf("6. Sair\n");
    system("pause>nul");
    scanf("%i", &opcao);
    system("cls || clear");
    gerenciarMenuPrincipal(opcao);
}
void gerenciarMenuPrincipal(int opcao)
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Menu de ger�nciar o menu principal                                     //
//Par�metro: Numero inteiro com a ops��o                                        //
//output: ger�nciar menu principal                                             //
////////////////////////////////////////////////////////////////////////////////
{
    switch(opcao)
    {
        case 1:
            loginAdm();
            break;
        case 2:
            montarMenuCliente();
            break;
        case 3:
            montarMenuEstabelecimento();
            break;
        case 4:
            configurarTela();
            break;
        case 5:
            sobre();
        case 6:
            sair();
        default:
            printf("Digite uma op��o v�lida!\n");
            system("pause");
            montarMenuPrincipal();
    }
}
int main()
////////////////////////////////////////////////////////////////////////////////////
//Fun��o: Tela inicial                                                           //
//Par�metro: N�o tem                                                            //
//output: Tela inicial                                                         //
////////////////////////////////////////////////////////////////////////////////
{
    int var;
    system("title PIM - UNIMUSIC");
    system("color F0");
    setlocale(LC_ALL, "Portuguese");
    printf("\n\n\t\tUNIMUSIC - PLATAFORMA DO RAMO MUSICAL\n\n");
    printf("\tVeja todas as fun��es disponiveis no menu.\n");
    printf("\tUse os numeros para selecionar a op��o desejada.\n");
    printf("\tPressione qualquer tecla para continuar ou espa�o para sair do programa agora.\n");
    printf("\n\n");
    printf("\t\t          P  /_\\  P                              \n");
    printf("\t\t         /_\\_|_|_/_\\                            \n");
    printf("\t\t     n_n | ||. .|| | n_n         Bem vindo ao     \n");
    printf("\t\t     |_|_|nnnn nnnn|_|_|        nosso programa!   \n");
    printf("\t\t    |\" \"  |  |_|  |\"  \" |                     \n");
    printf("\t\t    |_____| ' _ ' |_____|                         \n");
    printf("\t\t          \\__|_|__/                              \n");
    printf("\n\n");
    var=getch();
    if(var == 32){ exit(0);}
    system("cls || clear");
    montarMenuPrincipal();
    system("pause");
}
